<?php

namespace  App\Interfaces\Api;

interface AprobatorLogicInterface
{

    public function validateVacation();
}
