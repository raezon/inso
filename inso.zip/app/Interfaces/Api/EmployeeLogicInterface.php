<?php

namespace  App\Interfaces\Api;

interface EmployeeLogicInterface{

    public function consume();
}