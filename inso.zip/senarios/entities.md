i will describe all entities needed on this project
migrations

[x] user
[x] hospital  (name image adress latitutde longitude number phone)
[x] speciality name image
[x] request user (name,surname,phone_number,card_id)
[x] acounts uui,name,surname,id number,birthdate,address,type 
[x] settings (about us ,logo)
[x] social media (name ,link)
[x] carousels (image,description,titles)
[x] CurrentClients (image,title,description)
